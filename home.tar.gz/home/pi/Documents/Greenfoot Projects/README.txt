Greenfoot version: 2.4.2a

Information about Greenfoot
-----------------------
Information about Greenfoot, including system documentation is available at

  http://www.greenfoot.org/

Greenfoot usage data
--------------------
When you use Greenfoot, some anonymous non-personal information (Greenfoot 
version, Java version, Operating System, interface language, etc) is sent 
to the Greenfoot maintainers, to help with development planning. This can 
be disabled by adding a "greenfoot.uid=private" setting to your 
greenfoot.properties file. 

The Greenfoot Team
--------------
Greenfoot is being developed by:
University of Kent: Michael Kölling, Ian Utting, Davin McCall, Neil Brown, Phil Stevens

The copyright (c) for Greenfoot is held by P. Henriksen and M. Kölling.
